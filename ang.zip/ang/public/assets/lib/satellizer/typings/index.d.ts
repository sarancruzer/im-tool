/// <reference path="../satellizer.d.ts" />
/// <reference path="globals/angular-mocks/index.d.ts" />
/// <reference path="globals/angular-route/index.d.ts" />
/// <reference path="globals/angular/index.d.ts" />
/// <reference path="globals/es6-shim/index.d.ts" />
/// <reference path="globals/jasmine/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
/// <reference path="globals/node/index.d.ts" />
