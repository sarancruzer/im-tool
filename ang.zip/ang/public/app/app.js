var app =  angular.module('authApp', ['ui.router', 'satellizer']);


